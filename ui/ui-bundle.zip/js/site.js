// Maildeno Docs — site JS (tab switching)
;(function () {
  'use strict'
  document.querySelectorAll('.tablist').forEach(function (tablist) {
    tablist.querySelectorAll('a').forEach(function (tab) {
      tab.addEventListener('click', function (e) {
        e.preventDefault()
        var panel = document.getElementById(tab.getAttribute('href').slice(1))
        if (!panel) return
        var container = tablist.closest('.tabs')
        container.querySelectorAll('.tablist a').forEach(function (t) { t.classList.remove('is-selected') })
        container.querySelectorAll('.tab-content > .tab-panel').forEach(function (p) { p.setAttribute('hidden', '') })
        tab.classList.add('is-selected')
        panel.removeAttribute('hidden')
      })
    })
  })
})()
