/* Maildeno Docs — site.js */
;(function () {
  'use strict';

  /* ── Sidebar toggle (mobile) ──────────────────────────── */
  var sidebar  = document.getElementById('sidebar');
  var toggle   = document.getElementById('sidebarToggle');
  var overlay  = document.getElementById('sidebarOverlay');

  function openSidebar() {
    sidebar.classList.add('is-open');
    overlay.classList.add('is-visible');
    overlay.setAttribute('aria-hidden', 'false');
    toggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    sidebar.classList.remove('is-open');
    overlay.classList.remove('is-visible');
    overlay.setAttribute('aria-hidden', 'true');
    toggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  if (toggle) toggle.addEventListener('click', function () {
    sidebar.classList.contains('is-open') ? closeSidebar() : openSidebar();
  });
  if (overlay) overlay.addEventListener('click', closeSidebar);

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSidebar();
  });

  /* ── Nested nav group toggles ─────────────────────────── */
  document.querySelectorAll('[data-nav-group]').forEach(function (btn) {
    var sublist = btn.nextElementSibling;
    if (!sublist) return;

    // Auto-expand the group containing the active page
    if (sublist.querySelector('.nav__link--active')) {
      sublist.classList.add('is-open');
      btn.setAttribute('aria-expanded', 'true');
    }

    btn.addEventListener('click', function () {
      var expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!expanded));
      sublist.classList.toggle('is-open', !expanded);
    });
  });


  /* ── Active nav link (match current URL) ─────────────── */
  var currentPath = window.location.pathname.replace(/\/index\.html$/, '/');
  document.querySelectorAll('.nav__link[data-item-url]').forEach(function (a) {
    var itemUrl = a.getAttribute('data-item-url');
    // Normalise both to handle index.html
    var normItem = itemUrl.replace(/\/index\.html$/, '/');
    var normCurrent = currentPath;
    if (normItem === normCurrent || itemUrl === window.location.pathname) {
      a.classList.add('nav__link--active');
      // Expand parent group if inside one
      var sublist = a.closest('.nav__sublist');
      if (sublist) {
        sublist.classList.add('is-open');
        var groupBtn = sublist.previousElementSibling;
        if (groupBtn && groupBtn.dataset.navGroup !== undefined) {
          groupBtn.setAttribute('aria-expanded', 'true');
        }
      }
    }
  });

  /* ── Right ToC: build from article headings ───────────── */
  var tocNav  = document.getElementById('tocNav');
  var article = document.getElementById('article');

  if (tocNav && article) {
    var headings = article.querySelectorAll('h2, h3');
    if (headings.length > 0) {
      var frag = document.createDocumentFragment();
      headings.forEach(function (h) {
        if (!h.id) return;
        var a = document.createElement('a');
        a.href = '#' + h.id;
        a.textContent = h.textContent.replace(/^#\s*/, '');
        a.dataset.level = h.tagName === 'H3' ? '3' : '2';
        frag.appendChild(a);
      });
      tocNav.appendChild(frag);

      /* IntersectionObserver: highlight active heading */
      var tocLinks = tocNav.querySelectorAll('a');
      var headingMap = {};
      tocLinks.forEach(function (a) {
        var id = a.getAttribute('href').slice(1);
        headingMap[id] = a;
      });

      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            tocLinks.forEach(function (l) { l.classList.remove('is-active'); });
            var link = headingMap[entry.target.id];
            if (link) link.classList.add('is-active');
          }
        });
      }, { rootMargin: '-' + (parseInt(getComputedStyle(document.documentElement).getPropertyValue('--topnav-h')) + 8) + 'px 0px -70% 0px' });

      headings.forEach(function (h) { if (h.id) observer.observe(h); });
    } else {
      /* No headings — hide the ToC panel entirely */
      var tocEl = document.getElementById('toc');
      if (tocEl) tocEl.style.display = 'none';
    }
  }

  /* ── Sidebar search ───────────────────────────────────── */
  var searchInput = document.getElementById('docsSearch');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      var q = this.value.trim().toLowerCase();
      document.querySelectorAll('.nav__item:not(.nav__item--group)').forEach(function (li) {
        var text = (li.textContent || '').toLowerCase();
        li.classList.toggle('nav__item--hidden', q.length > 0 && !text.includes(q));
      });
      /* Auto-expand groups when searching */
      if (q.length > 0) {
        document.querySelectorAll('[data-nav-group]').forEach(function (btn) {
          var sublist = btn.nextElementSibling;
          if (sublist && sublist.querySelector('.nav__item:not(.nav__item--hidden)')) {
            sublist.classList.add('is-open');
            btn.setAttribute('aria-expanded', 'true');
          }
        });
      }
    });
  }

  /* ── Tab panels (@asciidoctor/tabs) ──────────────────── */
  document.querySelectorAll('.tablist, .tab-list').forEach(function (tablist) {
    var tabs = tablist.querySelectorAll('[role="tab"], .tab');
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function (e) {
        e.preventDefault();
        var panelId = tab.getAttribute('aria-controls') || tab.getAttribute('data-tab');
        if (!panelId) {
          var href = tab.getAttribute('href');
          if (href && href.startsWith('#')) panelId = href.slice(1);
        }
        if (!panelId) return;
        var panel = document.getElementById(panelId);
        if (!panel) return;
        var container = tablist.closest('[role="tabpanel"]') || tablist.closest('.tabs') || tablist.parentElement;
        /* deactivate all */
        tablist.querySelectorAll('[role="tab"], .tab').forEach(function (t) {
          t.classList.remove('is-selected');
          t.setAttribute('aria-selected', 'false');
        });
        container.querySelectorAll('.tab-panel, [role="tabpanel"]').forEach(function (p) {
          p.setAttribute('hidden', '');
        });
        /* activate chosen */
        tab.classList.add('is-selected');
        tab.setAttribute('aria-selected', 'true');
        panel.removeAttribute('hidden');
      });
    });
  });

})();
